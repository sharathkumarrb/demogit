// Saving the registration data from signup page
let Signupform = document.getElementById("signupform");
let passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z\d]).{8,}$/;

if (Signupform) {
    Signupform.addEventListener("submit", function(event) {
        event.preventDefault();

        let name = document.getElementById("Name").value.trim();
        let email = document.getElementById("Email").value.trim();
        let password = document.getElementById("Password").value;

        if (name == "" || email == "" || password == "") {
            alert("All Fields Required");
            return;
        }

        if (!passwordPattern.test(password)) {
            alert("Password must contain at least 1 capital letter, 1 small letter, 1 number, 1 special character and minimum 8 characters");
            return;
        }

        // JavaScript object creation
        let user = {
            name: name,
            email: email,
            password: password
        };

        localStorage.setItem("user", JSON.stringify(user));
        alert("Signed Up Successfully!");
    });
}

let Loginform = document.getElementById("loginForm");

if (Loginform) {
    Loginform.addEventListener("submit", function(event) {
        event.preventDefault();

        let email = document.getElementById("Email").value.trim();
        let password = document.getElementById("Password").value;

        let user = JSON.parse(localStorage.getItem("user"));

        if (user && email == user.email && password == user.password) {
            localStorage.setItem("loggedInUser", JSON.stringify(user));
            alert("Login Successful!");
            localStorage.setItem("isLoggedIn", "true");
            window.location.href = "index.html";

        } else {
            alert("Invalid email or password. Please try again.");
        }
    });
}

let heading = document.getElementById("WelcomeMessage");

if (heading) {
    let user = JSON.parse(localStorage.getItem("user"));
    let isLoggedIn = localStorage.getItem("loggedInUser");

    if (user && isLoggedIn) {
        heading.innerHTML = "Welcome " + user.name + " !";
    }
}
